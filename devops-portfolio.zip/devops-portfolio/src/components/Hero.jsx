import { useEffect, useRef, useState } from 'react'
import { profile, pipeline, ui } from '../data/content'
import { kurangGerak } from '../lib/hooks'
import { Check, Dot, Loader, Copy, Arrow } from './Icons'

const tahapan = pipeline.slice(0, 5)
const DURASI = [900, 1500, 1800, 1100, 1400]

export default function Hero() {
  const [langkah, setLangkah] = useState(kurangGerak() ? tahapan.length : -1)
  const [nomor, setNomor] = useState(1284)
  const [tersalin, setTersalin] = useState(false)
  const timer = useRef(null)

  // Menjalankan satu "deploy" dari tahap pertama sampai selesai, lalu ulang.
  useEffect(() => {
    if (kurangGerak()) return
    let i = -1
    const maju = () => {
      i += 1
      setLangkah(i)
      if (i < tahapan.length) {
        timer.current = setTimeout(maju, DURASI[i] ?? 1200)
      } else {
        timer.current = setTimeout(() => {
          setNomor((n) => n + 1)
          i = -1
          maju()
        }, 5200)
      }
    }
    timer.current = setTimeout(maju, 500)
    return () => clearTimeout(timer.current)
  }, [])

  const salinEmail = async () => {
    try {
      await navigator.clipboard.writeText(profile.email)
      setTersalin(true)
      setTimeout(() => setTersalin(false), 1800)
    } catch {
      window.location.href = `mailto:${profile.email}`
    }
  }

  const selesai = langkah >= tahapan.length

  return (
    <header className="hero" id="atas">
      <div className="wrap hero-grid">
        <div>
          <span className="avail">
            <span className="pulse" aria-hidden="true" />
            {profile.labelKetersediaan}
          </span>

          <h1>
            {profile.judulBaris1}
            <span className="thin">{profile.judulBaris2}</span>
          </h1>

          <div className="name">
            {profile.nama} — {profile.lokasi}
          </div>
          <p className="tagline">{profile.tagline}</p>

          <div className="cta-row">
            <a className="btn solid" href="#projects">
              {ui.hero.ctaUtama} <Arrow width="14" height="14" />
            </a>
            <button className="btn" onClick={salinEmail}>
              <Copy width="14" height="14" />
              {tersalin ? 'Email tersalin' : ui.hero.ctaKedua}
            </button>
            {profile.cv && (
              <a className="btn" href={profile.cv} target="_blank" rel="noreferrer">
                Unduh CV
              </a>
            )}
          </div>
        </div>

        {/* Panel deploy: pipeline yang benar-benar berjalan di layar */}
        <div className="deckpanel" aria-hidden="true">
          <header>
            <span className="dots">
              <i />
              <i />
              <i />
            </span>
            <span>deploy · main</span>
            <span className="run">#{nomor}</span>
          </header>

          <div className="runlist">
            {tahapan.map((t, i) => {
              const state = langkah > i ? 'done' : langkah === i ? 'running' : 'pending'
              return (
                <div className="runrow" key={t.id} data-state={state}>
                  <span className="st">
                    {state === 'done' ? (
                      <Check width="14" height="14" />
                    ) : state === 'running' ? (
                      <Loader width="14" height="14" />
                    ) : (
                      <Dot width="14" height="14" />
                    )}
                  </span>
                  <span className="nm">{t.nama.toLowerCase()}</span>
                  <span className="tm">{state === 'pending' ? '—' : t.durasi}</span>
                </div>
              )
            })}
          </div>

          <div className="deckfoot">
            <span className="ok">{selesai ? '✓' : '·'}</span>
            <span>
              {selesai
                ? 'rilis sehat · tanpa downtime'
                : 'menjalankan pipeline...'}
            </span>
          </div>
        </div>
      </div>
    </header>
  )
}
