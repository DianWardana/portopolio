import { useState } from 'react'
import { stack, kategoriStack, ui } from '../data/content'

export default function StackSection() {
  const [aktif, setAktif] = useState('Semua')
  const daftar = aktif === 'Semua' ? stack : stack.filter((s) => s.kategori === aktif)

  return (
    <section className="band" id="stack">
      <div className="wrap">
        <div className="section-head" data-reveal>
          <span className="eyebrow">perkakas</span>
          <h2>{ui.stackJudul}</h2>
          <p>{ui.stackDeskripsi}</p>
        </div>

        <div className="filters" data-reveal>
          {kategoriStack.map((k) => (
            <button
              key={k}
              className="filter"
              aria-pressed={aktif === k}
              onClick={() => setAktif(k)}
            >
              {k}
              {k !== 'Semua' && (
                <span style={{ opacity: 0.5 }}>
                  {' '}
                  {stack.filter((s) => s.kategori === k).length}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="stack-grid" data-reveal>
          {daftar.map((s, i) => (
            <div className="tool" key={s.nama} style={{ animationDelay: `${i * 30}ms` }}>
              <div className="hd">
                <span className="nm">{s.nama}</span>
                <span className="kt">{s.kategori}</span>
              </div>
              <div
                className="bar"
                role="img"
                aria-label={`Level ${s.level} dari 5`}
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <i key={n} className={n <= s.level ? 'on' : ''} />
                ))}
              </div>
              <div className="nt">{s.catatan}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
